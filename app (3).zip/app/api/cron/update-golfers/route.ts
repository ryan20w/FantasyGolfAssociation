import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(request: Request) {
  // 1. Verify Vercel Cron Secret
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  try {
    // 2. Fetch Official World Golf Rankings from RapidAPI
    const rankingsResponse = await fetch('https://live-golf-data.p.rapidapi.com/rankings', {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': process.env.RAPIDAPI_KEY!,
        'X-RapidAPI-Host': 'live-golf-data.p.rapidapi.com',
      },
    });

    if (!rankingsResponse.ok) {
      throw new Error(`Rankings fetch failed: ${rankingsResponse.status}`);
    }

    const rankingsData = await rankingsResponse.json();

    // 3. Upsert golfers into Supabase (Inserts missing players, updates existing ones)
    const golfersToUpsert = (rankingsData.rankings || []).map((player: { fullName: string; rank: number }) => ({
      name: player.fullName,
      owgr_rank: player.rank,
      updated_at: new Date().toISOString(),
    }));

    if (golfersToUpsert.length > 0) {
      const { error } = await supabase
        .from('golfers')
        .upsert(golfersToUpsert, { onConflict: 'name' });

      if (error) {
        throw new Error(`Supabase upsert error: ${error.message}`);
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully populated/updated ${golfersToUpsert.length} golfers in Supabase.`,
    });
  } catch (error: unknown) {
    console.error('Error updating golfers:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return NextResponse.json({ success: false, error: errorMessage }, { status: 500 });
  }
}